
<footer style="height: 200px;position:absolute;bottom:0;right:0;left:0;text-align: center;">
	<a class="a" href="?categorie=t-shirt">
		T-shirt
	</a> - 
	<a class="a" href="?categorie=pull">
		Pull
	</a> - 
	<a class="a" href="?categorie=jeans">
		Jeans
	</a> - 
	<a class="a" href="?categorie=chaussette">
		Chaussette
	</a><br/>
	<a class="a" href="index.php">
		All
	</a>
	<br/><br/>
	<a href="https://github.com/Chnapy/ryzaha" target="_blank">
		<img src="img/apropos/GitHub-Mark-32px.png" style="filter: invert(100%);"/>
	</a>
	<a href="https://trello.com/b/CTCccS7b/ryzaha" target="_blank">
		<img src="https://d2k1ftgv7pobq7.cloudfront.net/meta/u/res/images/trello-header-logos/af7af6ed478d3460709d715d9b3f74a4/trello-logo-white.svg" style="height: 32px;"/>
	</a>
	<br/>
	Les prix affichés ne prennent pas en compte d'éventuels frais de dossier.<br/>
	Ryzaha.com et ses associés se réservent le droit d'utiliser dans des proportions dîtes <i>raisonnables</i> les informations bancaires enregistrées.<br/>
	© 2016, Ryzaha.com, Inc. ou ses filiales.
</footer>