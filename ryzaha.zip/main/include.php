<?php

		require_once 'main/spdo.php';
		
	 require_once 'content/client/HeadConnecte.php';
	 require_once 'content/client/HeadDeconnecte.php';
	 require_once 'content/client/Client.php';
		require_once 'content/produit.php';
